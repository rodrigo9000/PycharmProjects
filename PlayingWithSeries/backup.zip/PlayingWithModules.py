print "This is getting serious!"
var = "backup.zip"
print var.split('.')[0]